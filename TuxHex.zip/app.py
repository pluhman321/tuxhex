from flask import Flask, render_template, request
from modules import scanner, utils

app = Flask(__name__)

@app.route('/')
def index():
    ip = utils.get_local_ip()
    devices = scanner.arp_scan(ip)
    return render_template('index.html', devices=devices, ip=ip)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
