# TuxHex

A basic Raspberry Pi-friendly pentesting dashboard with CLI + Web UI.

## Features

- ARP scan for device discovery
- Local IP and interface info
- Simple Flask web dashboard

## Run CLI
```
python3 tuxhex.py
```

## Run Web Dashboard
```
python3 app.py
```
Visit `http://<raspberrypi_ip>:8080`
