from modules import scanner, utils

def main():
    print("[TuxHex CLI]")
    ip = utils.get_local_ip()
    print(f"Local IP: {ip}")
    devices = scanner.arp_scan(ip)
    for dev in devices:
        print(f"{dev['ip']} - {dev['mac']}")

if __name__ == "__main__":
    main()
